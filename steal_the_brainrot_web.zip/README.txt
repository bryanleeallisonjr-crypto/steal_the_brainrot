Steal the Brainrot — Web (HTML5)
=================================
Files included:
- index.html
- style.css
- game.js

How to play locally:
1. Extract the zip to a folder.
2. Open index.html in a modern browser (Chrome, Edge, Firefox).
   - The game uses Phaser 3 from a CDN. Make sure you have internet access when first loading.
3. Controls:
   - Move: WASD or Arrow keys
   - Bonk (steal): Space
   - Restart: R
4. Objective: collect orbs to increase your "Rot". Bonk nearby bots to steal their rot.

Want changes?
- I can add keyboard-tuneable settings, sound effects, better AI, local multiplayer, or export as a downloadable desktop app (Electron).
