// Steal the Brainrot - Phaser 3 implementation (single-player with bots)
const config = {
  type: Phaser.AUTO,
  parent: 'game-container',
  width: Math.min(1280, window.innerWidth),
  height: Math.min(720, window.innerHeight),
  physics: {
    default: 'arcade',
    arcade: { debug: false }
  },
  scene: { preload, create, update }
};
const game = new Phaser.Game(config);

let player, cursors, spaceKey, orbGroup, bots, scoreTextDiv, restartKey;
const BOT_COUNT = 6;
const ORB_SPAWN_INTERVAL = 1500; // ms
const ORB_LIFETIME = 20000; // ms
const BONK_RANGE = 64;

function preload() {
  // no external assets required — we'll use graphics
}

function create() {
  const scene = this;
  // background
  scene.cameras.main.setBackgroundColor('#121212');

  // groups
  orbGroup = scene.physics.add.group();
  bots = [];

  // player
  player = createPlayer(scene, scene.scale.width/2, scene.scale.height/2, 0x66ccff, 'You');
  player.isPlayer = true;

  // bots
  for (let i=0;i<BOT_COUNT;i++) {
    const x = Phaser.Math.Between(50, scene.scale.width-50);
    const y = Phaser.Math.Between(50, scene.scale.height-50);
    const bot = createPlayer(scene, x, y, getRandomColor(), 'Bot'+(i+1));
    bot.isBot = true;
    bots.push(bot);
  }

  // collisions & overlaps
  scene.physics.add.overlap(player.sprite, orbGroup, (p, orb) => {
    collectOrb(scene, player, orb);
  });
  bots.forEach(b => {
    scene.physics.add.overlap(b.sprite, orbGroup, (s, orb) => {
      collectOrb(scene, b, orb);
    });
  });

  // input
  cursors = scene.input.keyboard.createCursorKeys();
  spaceKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
  restartKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.R);

  // UI
  scoreTextDiv = document.getElementById('scores');
  updateScoresUI();

  // spawn orbs repeatedly
  scene.time.addEvent({
    delay: ORB_SPAWN_INTERVAL, loop: true, callback: ()=> spawnOrb(scene)
  });

  // bot AI timer
  scene.time.addEvent({ delay: 500, loop: true, callback: ()=> botBehavior(scene) });

  // make camera bounds large enough
  scene.cameras.main.setBounds(0,0,scene.scale.width, scene.scale.height);
}

function update(time, delta) {
  const scene = this;
  handlePlayerMovement(scene);
  handleBonk(scene);
  if (Phaser.Input.Keyboard.JustDown(restartKey)) {
    scene.scene.restart();
  }
}

// ---------- Helpers ----------
function createPlayer(scene, x, y, color, name) {
  const g = scene.add.graphics();
  g.fillStyle(color, 1);
  g.fillCircle(0,0,18);
  const textureKey = 'circle-' + Phaser.Math.RND.integer();
  g.generateTexture(textureKey, 40,40);
  g.destroy();
  const sprite = scene.physics.add.sprite(x,y,textureKey);
  sprite.setCollideWorldBounds(true);
  sprite.setDrag(600,600);
  sprite.setMaxVelocity(220,220);
  const label = scene.add.text(x, y+24, name, { fontSize:'12px', color:'#fff' }).setOrigin(0.5,0);
  return { sprite, rot: 0, name, label, color };
}

function spawnOrb(scene) {
  const x = Phaser.Math.Between(32, scene.scale.width-32);
  const y = Phaser.Math.Between(32, scene.scale.height-32);
  const orb = scene.add.circle(x,y,10,0xff66cc);
  scene.physics.add.existing(orb);
  orb.body.setCircle(10);
  orb.body.immovable = true;
  orb.body.moves = false;
  orb.name = 'orb';
  orb.collected = false;
  orbGroup.add(orb);
  // lifetime
  scene.time.delayedCall(ORB_LIFETIME, ()=> { if (orb && orb.active) orb.destroy(); });
}

function collectOrb(scene, who, orb) {
  if (!orb.active || orb.collected) return;
  orb.collected = true;
  orb.destroy();
  who.rot += 1;
  playPickupEffect(scene, who.sprite.x, who.sprite.y);
  updateScoresUI();
}

function playPickupEffect(scene,x,y){
  const p = scene.add.particles(null);
  const emitter = p.createEmitter({
    x,y,
    lifespan:300, speed:{min:50,max:120}, scale:{start:0.6, end:0},
    quantity:8, blendMode:'ADD'
  });
  scene.time.delayedCall(400, ()=> { p.destroy(); });
}

function handlePlayerMovement(scene) {
  const speed = 220;
  let vx=0, vy=0;
  if (cursors.left.isDown || scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A).isDown) vx = -1;
  if (cursors.right.isDown || scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D).isDown) vx = 1;
  if (cursors.up.isDown || scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W).isDown) vy = -1;
  if (cursors.down.isDown || scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S).isDown) vy = 1;
  player.sprite.setAcceleration(vx * speed * 4, vy * speed * 4);
  // update label position
  player.label.setPosition(player.sprite.x, player.sprite.y + 24);
  // bots labels
  bots.forEach(b => b.label.setPosition(b.sprite.x, b.sprite.y + 24));
}

function handleBonk(scene) {
  if (Phaser.Input.Keyboard.JustDown(spaceKey)) {
    // find closest bot within range
    let target = null;
    let bestDist = BONK_RANGE;
    bots.forEach(b => {
      const d = Phaser.Math.Distance.Between(player.sprite.x, player.sprite.y, b.sprite.x, b.sprite.y);
      if (d < bestDist) { bestDist = d; target = b; }
    });
    if (target) {
      doSteal(scene, player, target);
    } else {
      // maybe bonk orb to get some small random rot
      // or a harmless thump animation
      flashText(scene, player.sprite.x, player.sprite.y - 30, 'No target!', '#ffcc66');
    }
  }
}

function doSteal(scene, from, target) {
  const amount = Math.min(target.rot, Phaser.Math.Between(1, Math.min(3, Math.max(1, Math.floor(target.rot/2)))));
  if (amount <= 0) {
    // nothing to steal; small push
    flashText(scene, player.sprite.x, player.sprite.y - 30, 'No Rot to steal!', '#cccccc');
    return;
  }
  target.rot -= amount;
  from.rot += amount;
  // effects
  flashText(scene, target.sprite.x, target.sprite.y - 30, '-' + amount, '#ff6699');
  flashText(scene, from.sprite.x, from.sprite.y - 30, '+' + amount, '#66ffcc');
  // small knockback
  const angle = Phaser.Math.Angle.Between(target.sprite.x, target.sprite.y, from.sprite.x, from.sprite.y);
  target.sprite.body.velocity.x -= Math.cos(angle) * 200;
  target.sprite.body.velocity.y -= Math.sin(angle) * 200;
  updateScoresUI();
}

function flashText(scene, x, y, text, color) {
  const t = scene.add.text(x,y,text,{ fontSize:'18px', color: color||'#fff', fontStyle:'bold' }).setOrigin(0.5);
  scene.tweens.add({ targets: t, y: y-30, alpha:0, duration:700, ease:'Cubic.easeOut', onComplete: ()=> t.destroy() });
}

function botBehavior(scene) {
  // each bot either chases nearest orb or occasionally tries to bonk player
  bots.forEach(b => {
    if (!b || !b.sprite || !b.sprite.body) return;
    // 20% chance to attempt bonk if near player
    const distToPlayer = Phaser.Math.Distance.Between(b.sprite.x, b.sprite.y, player.sprite.x, player.sprite.y);
    if (distToPlayer < BONK_RANGE*1.2 && Math.random() < 0.2) {
      // attempt to steal from player
      if (player.rot > 0) {
        const steal = Math.min(player.rot, Phaser.Math.Between(1, Math.min(3, Math.max(1, Math.floor(player.rot/2)))));
        player.rot -= steal;
        b.rot += steal;
        flashText(scene, player.sprite.x, player.sprite.y - 30, '-' + steal, '#ff6699');
        flashText(scene, b.sprite.x, b.sprite.y - 30, '+' + steal, '#66ffcc');
        updateScoresUI();
        // small recoil
        const angle = Phaser.Math.Angle.Between(player.sprite.x, player.sprite.y, b.sprite.x, b.sprite.y);
        player.sprite.body.velocity.x -= Math.cos(angle) * 200;
        player.sprite.body.velocity.y -= Math.sin(angle) * 200;
        return;
      }
    }
    // otherwise chase nearest orb if any
    let nearestOrb = null;
    let best = 99999;
    orbGroup.getChildren().forEach(o => {
      const d = Phaser.Math.Distance.Between(b.sprite.x, b.sprite.y, o.x, o.y);
      if (d < best) { best = d; nearestOrb = o; }
    });
    if (nearestOrb) {
      scene.physics.moveToObject(b.sprite, nearestOrb, 120);
    } else {
      // wander
      if (!b._targetPoint || Phaser.Math.Distance.Between(b.sprite.x, b.sprite.y, b._targetPoint.x, b._targetPoint.y) < 16) {
        b._targetPoint = { x: Phaser.Math.Between(40, scene.scale.width-40), y: Phaser.Math.Between(40, scene.scale.height-40) };
      }
      scene.physics.moveTo(b.sprite, b._targetPoint.x, b._targetPoint.y, 80);
    }
  });
}

function updateScoresUI() {
  // sort players by rot
  const list = [player].concat(bots.slice());
  list.sort((a,b)=> b.rot - a.rot);
  let html = '<strong>Leaderboard</strong><br/>';
  list.forEach(p => {
    const name = p.isPlayer ? '<u>' + p.name + '</u>' : p.name;
    html += `${name}: ${p.rot} <br/>`;
  });
  scoreTextDiv.innerHTML = html;
}

function getRandomColor(){ const colors=[0xff6666,0x66ff66,0x6666ff,0xffcc66,0x66ccff,0xcc66ff]; return colors[Phaser.Math.Between(0,colors.length-1)]; }
