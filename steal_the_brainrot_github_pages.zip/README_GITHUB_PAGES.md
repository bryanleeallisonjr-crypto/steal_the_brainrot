Steal the Brainrot — GitHub Pages Package

What you got:
- index.html (PWA-ready)
- style.css
- game.js (Phaser game + optional WebSocket client)
- manifest.json
- service-worker.js
- assets/ (icons + sfx)
- server/ (optional Node server for local hosting + WebSocket)

Quick deploy to GitHub Pages (free):
1. Create a new GitHub repository (name it e.g. steal-the-brainrot).
2. Copy all files and folders from this package into the repo root.
3. Commit and push to GitHub:
   git init
   git add .
   git commit -m "Initial commit — Brainrot web game"
   git remote add origin git@github.com:<yourname>/<repo>.git
   git push -u origin main
4. In the repository, go to Settings → Pages. Set the source to branch 'main' and folder '/' then Save.
   Your site will be published at https://<yourname>.github.io/<repo>/

Notes:
- GitHub Pages serves static sites only. The optional WebSocket server won't run on GitHub Pages. For multiplayer chat you'll need to host server/server.js on a VPS or Heroku-like service.
- To test locally with WS, run the server script in /server (Node.js required).
