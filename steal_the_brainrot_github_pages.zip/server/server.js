// Simple static server + WebSocket example using Node.js
// Run: npm install express ws
//       node server.js
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const app = express();
const port = process.env.PORT || 8080;
app.use(express.static('..'));
const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });
let clients = new Map();
let nextId = 1;
wss.on('connection', (ws)=>{
  const id = 'p' + (nextId++);
  clients.set(ws, { id, name: 'Anonymous', rot:0 });
  ws.send(JSON.stringify({ type:'id', id }));
  ws.on('message', (msg)=>{
    try { const data = JSON.parse(msg.toString()); if(data.type==='join'){ clients.get(ws).name = data.name || 'Anonymous'; } if(data.type==='chat'){ for(const c of clients.keys()) if(c.readyState===WebSocket.OPEN) c.send(JSON.stringify({ type:'chat', name:data.name, text:data.text, rot:data.rot, color:data.color })); } } catch(e){}
  });
  ws.on('close', ()=> clients.delete(ws));
});
server.listen(port, ()=> console.log('Static + WS server on port', port));
