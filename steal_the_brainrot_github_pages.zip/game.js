// Steal the Brainrot - Github Pages version (Phaser 3)
const BOT_COUNT = 6;
const ORB_SPAWN_INTERVAL = 1500;
const ORB_LIFETIME = 20000;
const BONK_RANGE = 64;

let player, cursors, spaceKey, orbGroup, bots, scoreTextDiv, restartKey;
let joystick = { active:false, startX:0, startY:0, dx:0, dy:0 };
let ws = null, clientId = null;

function getRandomColor(){ const colors=[0xff6666,0x66ff66,0x6666ff,0xffcc66,0x66ccff,0xcc66ff]; return colors[Phaser.Math.Between(0,colors.length-1)]; }
function getRank(rot){ if(rot>=100) return {name:'OMEGA',color:'#ff3366'}; if(rot>=60) return {name:'Diamond',color:'#66ccff'}; if(rot>=35) return {name:'Gold',color:'#ffcc33'}; if(rot>=15) return {name:'Silver',color:'#cccccc'}; return {name:'Bronze',color:'#bb7733'}; }

const config = { type: Phaser.AUTO, parent:'game-container', width: Math.min(1280, window.innerWidth), height: Math.min(720, window.innerHeight), physics:{ default:'arcade', arcade:{ debug:false } }, scene:{ preload, create, update } };
const game = new Phaser.Game(config);

function preload(){}
function create(){
  const scene = this;
  scene.cameras.main.setBackgroundColor('#101018');
  orbGroup = scene.physics.add.group();
  bots = [];

  player = createPlayer(scene, scene.scale.width/2, scene.scale.height/2, 0x66ccff, prompt('Enter your player name','You') || 'You');
  player.isPlayer = true; player.colorHex = '#66ccff';

  for(let i=0;i<BOT_COUNT;i++){ const x=Phaser.Math.Between(50,scene.scale.width-50); const y=Phaser.Math.Between(50,scene.scale.height-50); const b=createPlayer(scene,x,y,getRandomColor(),'Bot'+(i+1)); b.isBot=true; bots.push(b); }

  scene.physics.add.overlap(player.sprite, orbGroup, (p,orb)=> collectOrb(scene, player, orb));
  bots.forEach(b=> scene.physics.add.overlap(b.sprite, orbGroup, (s,orb)=> collectOrb(scene, b, orb)));

  cursors = scene.input.keyboard.createCursorKeys();
  spaceKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
  restartKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.R);

  scoreTextDiv = document.getElementById('scores');
  updateScoresUI();

  scene.time.addEvent({ delay: ORB_SPAWN_INTERVAL, loop:true, callback: ()=> spawnOrb(scene) });
  scene.time.addEvent({ delay: 500, loop:true, callback: ()=> botBehavior(scene) });

  initJoystick();
  document.getElementById('bonk-button').addEventListener('pointerdown', ()=> doPlayerBonk(scene));

  const input = document.getElementById('chat-input');
  input.addEventListener('keydown', (e)=>{ if(e.key==='Enter' && input.value.trim()!==''){ handleChatSend(input.value.trim()); input.value=''; } });

  // Attempt to auto-connect to WebSocket on same origin at /ws
  try { const proto = location.protocol === 'https:' ? 'wss:' : 'ws:'; const wsUrl = proto + '//' + location.host + '/ws'; connectWS(wsUrl); } catch(e){ console.log('ws not available'); }
}

function update(){ const scene=this; handlePlayerMovement(scene); if(Phaser.Input.Keyboard.JustDown(spaceKey)) doPlayerBonk(scene); if(Phaser.Input.Keyboard.JustDown(restartKey)) scene.scene.restart(); player.label.setPosition(player.sprite.x, player.sprite.y+22); bots.forEach(b=> b.label.setPosition(b.sprite.x,b.sprite.y+22)); }

function createPlayer(scene,x,y,color,name){ const g=scene.add.graphics(); g.fillStyle(color,1); g.fillCircle(0,0,18); const texture='c'+Phaser.Math.RND.integer(); g.generateTexture(texture,40,40); g.destroy(); const sprite=scene.physics.add.sprite(x,y,texture); sprite.setCollideWorldBounds(true); sprite.setDrag(600,600); sprite.setMaxVelocity(220,220); const label=scene.add.text(x,y+24,name,{fontSize:'12px',color:'#fff'}).setOrigin(0.5,0); return { sprite, rot:0, name, label, colorHex:'#ffffff' }; }
function spawnOrb(scene){ const x=Phaser.Math.Between(32,scene.scale.width-32); const y=Phaser.Math.Between(32,scene.scale.height-32); const orb=scene.add.circle(x,y,10,0xff66cc); scene.physics.add.existing(orb); orb.body.setCircle(10); orb.body.immovable=true; orb.body.moves=false; orb.name='orb'; orb.collected=false; orbGroup.add(orb); scene.time.delayedCall(ORB_LIFETIME, ()=> { if (orb && orb.active) orb.destroy(); }); }
function collectOrb(scene,who,orb){ if(!orb.active || orb.collected) return; orb.collected=true; orb.destroy(); who.rot+=1; playPickupEffect(scene, who.sprite.x, who.sprite.y); updateScoresUI(); if(ws && ws.readyState===WebSocket.OPEN && who.isPlayer) sendWS({type:'rot',rot:who.rot}); }
function playPickupEffect(scene,x,y){ const p=scene.add.particles(null); const em=p.createEmitter({ x,y, lifespan:300, speed:{min:50,max:120}, scale:{start:0.6,end:0}, quantity:8, blendMode:'ADD'}); scene.time.delayedCall(400, ()=> p.destroy()); }
function handlePlayerMovement(scene){ const speed=220; let vx=0,vy=0; if(cursors.left.isDown || scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A).isDown) vx=-1; if(cursors.right.isDown || scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D).isDown) vx=1; if(cursors.up.isDown || scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W).isDown) vy=-1; if(cursors.down.isDown || scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S).isDown) vy=1; if(joystick.active){ vx+=joystick.dx; vy+=joystick.dy; } player.sprite.setAcceleration(vx * speed * 4, vy * speed * 4); }
function doPlayerBonk(scene){ let target=null,best=BONK_RANGE; bots.forEach(b=>{ const d=Phaser.Math.Distance.Between(player.sprite.x,player.sprite.y,b.sprite.x,b.sprite.y); if(d<best){ best=d; target=b; } }); if(target){ doSteal(scene,player,target); if(ws && ws.readyState===WebSocket.OPEN) sendWS({type:'steal',id:clientId,target:target.name}); } else { flashText(scene,player.sprite.x,player.sprite.y-30,'No target!','#ffcc66'); } }
function doSteal(scene,from,target){ const amount=Math.min(target.rot, Phaser.Math.Between(1, Math.min(3, Math.max(1, Math.floor(target.rot/2))))); if(amount<=0){ flashText(scene,player.sprite.x,player.sprite.y-30,'No Rot to steal!','#cccccc'); return; } target.rot-=amount; from.rot+=amount; flashText(scene,target.sprite.x,target.sprite.y-30,'-'+amount,'#ff6699'); flashText(scene,from.sprite.x,from.sprite.y-30,'+'+amount,'#66ffcc'); const angle=Phaser.Math.Angle.Between(target.sprite.x,target.sprite.y,from.sprite.x,from.sprite.y); target.sprite.body.velocity.x -= Math.cos(angle) * 200; target.sprite.body.velocity.y -= Math.sin(angle) * 200; updateScoresUI(); if(ws && ws.readyState===WebSocket.OPEN) sendWS({type:'rot',id:clientId,rot:player.rot}); }
function flashText(scene,x,y,text,color){ const t=scene.add.text(x,y,text,{fontSize:'18px',color:color||'#fff',fontStyle:'bold'}).setOrigin(0.5); scene.tweens.add({ targets:t, y:y-30, alpha:0, duration:700, ease:'Cubic.easeOut', onComplete:()=>t.destroy() }); }
function botBehavior(scene){ bots.forEach(b=>{ if(!b||!b.sprite||!b.sprite.body) return; const distToPlayer=Phaser.Math.Distance.Between(b.sprite.x,b.sprite.y,player.sprite.x,player.sprite.y); if(distToPlayer < BONK_RANGE*1.2 && Math.random() < 0.18){ if(player.rot>0){ const steal=Math.min(player.rot, Phaser.Math.Between(1, Math.min(3, Math.max(1, Math.floor(player.rot/2))))); player.rot-=steal; b.rot+=steal; flashText(scene,player.sprite.x,player.sprite.y-30,'-'+steal,'#ff6699'); flashText(scene,b.sprite.x,b.sprite.y-30,'+'+steal,'#66ffcc'); updateScoresUI(); const angle=Phaser.Math.Angle.Between(player.sprite.x,player.sprite.y,b.sprite.x,b.sprite.y); player.sprite.body.velocity.x -= Math.cos(angle) * 200; player.sprite.body.velocity.y -= Math.sin(angle) * 200; return; } } let nearest=null; let best=99999; orbGroup.getChildren().forEach(o=>{ const d=Phaser.Math.Distance.Between(b.sprite.x,b.sprite.y,o.x,o.y); if(d<best){ best=d; nearest=o; } }); if(nearest) scene.physics.moveToObject(b.sprite, nearest, 120); else { if(!b._targetPoint || Phaser.Math.Distance.Between(b.sprite.x,b.sprite.y,b._targetPoint.x,b._targetPoint.y) < 16) b._targetPoint = { x: Phaser.Math.Between(40, scene.scale.width-40), y: Phaser.Math.Between(40, scene.scale.height-40) }; scene.physics.moveTo(b.sprite, b._targetPoint.x, b._targetPoint.y, 80); } }); }
function updateScoresUI(){ const list=[player].concat(bots.slice()); list.sort((a,b)=> b.rot - a.rot); let html='<strong>Leaderboard</strong><br/>'; list.forEach(p=>{ const rank=getRank(p.rot); const icon=''; const name=p.isPlayer?('<u>'+p.name+'</u>'):p.name; html += '<span style="color:'+rank.color+'" class="rank-tag">'+rank.name+'</span> <span class="player-name">'+name+'</span> '+p.rot+'<br/>'; }); scoreTextDiv.innerHTML = html; }

// Chat
const chatMessages = document.getElementById('chat-messages');
function addChatMessage(playerObj, text){ const msg=document.createElement('div'); msg.className='chat-line'; const rank=getRank(playerObj.rot||0); const colorStyle = playerObj.colorHex ? 'color:'+playerObj.colorHex : ''; msg.innerHTML = '<span class="rank-tag" style="background:'+rank.color+'">'+rank.name+'</span> <strong style="'+colorStyle+'">'+playerObj.name+':</strong> ' + escapeHtml(text); chatMessages.appendChild(msg); chatMessages.scrollTop = chatMessages.scrollHeight; }
function escapeHtml(s){ return String(s).replace(/[&<>"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
function handleChatSend(text){ if(text.startsWith('/')){ const parts=text.split(' '); const cmd=parts[0].toLowerCase(); if(cmd==='/rank'){ const r=getRank(player.rot); addChatMessage({name:'System',rot:0,colorHex:'#ffcc66'}, 'Your rank: '+r.name+' (Rot: '+player.rot+')'); return; } if(cmd==='/color'&&parts[1]){ const c=parts[1]; if(/^#?[0-9a-fA-F]{6}$/.test(c)){ player.colorHex = c.startsWith('#')?c:'#'+c; addChatMessage({name:'System',rot:0,colorHex:'#66ff66'}, 'Color changed.'); updateScoresUI(); return; } else { addChatMessage({name:'System',rot:0,colorHex:'#ff6666'}, 'Invalid color. Use hex like /color #66ccff'); return; } } addChatMessage({name:'System',rot:0,colorHex:'#ffcc66'}, 'Unknown command.'); return; } addChatMessage(player, text); if(ws && ws.readyState === WebSocket.OPEN) sendWS({type:'chat',id:clientId,name:player.name,text,rot:player.rot,color:player.colorHex}); }

// Joystick (mobile)
function initJoystick(){ const base=document.getElementById('joystick-base'); const thumb=document.getElementById('joystick-thumb'); const maxRadius=40; function pointerDown(e){ joystick.active=true; joystick.startX = e.clientX || e.touches[0].clientX; joystick.startY = e.clientY || e.touches[0].clientY; thumb.style.transition='none'; } function pointerMove(e){ if(!joystick.active) return; const px = e.clientX || (e.touches && e.touches[0].clientX); const py = e.clientY || (e.touches && e.touches[0].clientY); joystick.dx = (px - joystick.startX)/maxRadius; joystick.dy = (py - joystick.startY)/maxRadius; const len = Math.sqrt(joystick.dx*joystick.dx + joystick.dy*joystick.dy); if(len>1){ joystick.dx /= len; joystick.dy /= len; } const tx = Math.max(-maxRadius, Math.min(maxRadius, (px - joystick.startX))); const ty = Math.max(-maxRadius, Math.min(maxRadius, (py - joystick.startY))); thumb.style.transform = 'translate(' + tx + 'px, ' + ty + 'px)'; } function pointerUp(e){ joystick.active=false; joystick.dx=0; joystick.dy=0; thumb.style.transition='transform 120ms ease-out'; thumb.style.transform='translate(-50%,-50%)'; } base.addEventListener('pointerdown', pointerDown); window.addEventListener('pointermove', pointerMove); window.addEventListener('pointerup', pointerUp); base.addEventListener('touchstart',(e)=>e.preventDefault(),{passive:false}); }

// WebSocket client helpers (optional server at /ws)
function connectWS(url){ try{ ws=new WebSocket(url);}catch(e){console.warn('ws invalid',e);return;} ws.onopen=()=>{ console.log('WS open'); sendWS({type:'join',name:player.name,rot:player.rot,color:player.colorHex}); }; ws.onmessage=(ev)=>{ try{ const data=JSON.parse(ev.data); if(data.type==='id') clientId=data.id; if(data.type==='chat') addChatMessage({name:data.name,rot:data.rot,colorHex:data.color}, data.text); if(data.type==='players') addChatMessage({name:'System',rot:0,colorHex:'#88ff88'}, 'Players online: ' + data.players.map(p=>p.name).join(', ')); }catch(e){console.warn(e);} }; ws.onclose=()=>{ ws=null; }; ws.onerror=(e)=>{ console.warn('ws error',e); }; }
function sendWS(obj){ if(!ws || ws.readyState !== WebSocket.OPEN) return; ws.send(JSON.stringify(obj)); }
